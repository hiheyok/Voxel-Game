#include "ChunkMeshing.h"

#include "../../../World/Chunk/Block/Blocks.h"
#include <unordered_set>

using namespace Meshing;

void ChunkMeshData::GenerateMesh(Chunk& chunk) {
	//Initialize

	NullQuad.h = 9999;
	NullQuad.w = 9999;
	NullQuad.x = 9999;
	NullQuad.y = 9999;

	NullQuad.Texture = 9999;

	FaceCollectionCache = new Quad[6 * 4096]{};

	Position = chunk.Position;

	//Generates the unsimplified mesh first

	GenerateFaceCollection(chunk); //Generates face with their respected textures

	//GenerateFaceLighting(chunk); //Add lighting to those faces

	SimplifyMesh(chunk);

	delete FaceCollectionCache;

}

bool ChunkMeshData::compareQuads(Quad q0, Quad q1) {
	if (q0.L_NN != q1.L_NN)
		return false;
	if (q0.L_PN != q1.L_PN)
		return false;
	if (q0.L_PP != q1.L_PP)
		return false;
	if (q0.L_NP != q1.L_NP)
		return false;
	if (q0.Texture != q1.Texture)
		return false;
	return true;
}

//Loops through all the blocks in the chunk and check if each block side is visible. If a block side is visible, it generates the quad and puts it in the cache

void ChunkMeshData::GenerateFaceCollection(Chunk& chunk) {
	for (int x = 0; x < 16; x++) {
		for (int y = 0; y < 16; y++) {
			for (int z = 0; x < 16; x++) {
				for (int side = 0; side < 6; side++) {
					if (IsFaceVisible(chunk, x, y, z, side)) {
						Quad quad;
						
						quad.Texture = GetTexture(chunk, x, y, z, side);

						SetFace(x, y, z, side, quad);
					}
					else {
						SetFace(x, y, z, side, NullQuad);
					}
				}
			}
		}
	}
}

//This generates the lighting by looping through all the blocks in the chunk. If it finds a block that is solid, it will check if there's another block near it that forms a corner, and it makes that spot just a little darker

void ChunkMeshData::GenerateFaceLighting(Chunk& chunk) {
	for (int x = 0 - 1; x < 16 + 1; x++) {
		for (int y = 0 - 1; y < 16 + 1; y++) {
			for (int z = 0 - 1; z < 16 + 1; z++) {

				if (chunk.GetBlock(x,y,z) != AIR) {
					Quad PositiveX = GetFace(x, y, z, PX);
					Quad PositiveY = GetFace(x, y, z, PY);
					Quad PositiveZ = GetFace(x, y, z, PZ);

					Quad NegativeX = GetFace(x, y, z, NX);
					Quad NegativeY = GetFace(x, y, z, NY);
					Quad NegativeZ = GetFace(x, y, z, NZ);

					if (chunk.GetBlock(x + 1, y + 1, z) != AIR) {
						PositiveX.L_NP = 10;
						PositiveX.L_PP = 10;
						PositiveY.L_PN = 10;
						PositiveY.L_PP = 10;
						if (chunk.GetBlock(x + 1, y + 1, z + 1) != AIR) {
							PositiveX.L_NP = 10;
							PositiveY.L_PP = 10;
							PositiveZ.L_PP = 10;
						}
						if (chunk.GetBlock(x + 1, y + 1, z - 1) != AIR) {
							PositiveX.L_NP = 10;
							PositiveY.L_PN = 10;
							NegativeZ.L_PP = 10;
						}
					}
					if (chunk.GetBlock(x - 1, y + 1, z) != AIR) {
						NegativeX.L_NP = 10;
						NegativeX.L_PP = 10;
						PositiveY.L_NN = 10;
						PositiveY.L_NP = 10;
						if (chunk.GetBlock(x - 1, y + 1, z + 1) != AIR) {
							NegativeX.L_NP = 10;
							PositiveY.L_NP = 10;
							PositiveZ.L_NP = 10;
						}
						if (chunk.GetBlock(x - 1, y + 1, z - 1) != AIR) {
							NegativeX.L_NP = 10;
							PositiveY.L_NN = 10;
							NegativeZ.L_NP = 10;
						}
					}
					if (chunk.GetBlock(x, y + 1, z + 1) != AIR) {
						PositiveZ.L_NP = 10;
						PositiveZ.L_PP = 10;
						PositiveY.L_NP = 10;
						PositiveY.L_PP = 10;
						if (chunk.GetBlock(x + 1, y + 1, z + 1) != AIR) {
							PositiveX.L_NP = 10;
							PositiveY.L_PP = 10;
							PositiveZ.L_PP = 10;
						}
						if (chunk.GetBlock(x - 1, y + 1, z + 1) != AIR) {
							NegativeX.L_NP = 10;
							PositiveY.L_NP = 10;
							PositiveZ.L_NP = 10;
						}
					}
					if (chunk.GetBlock(x, y + 1, z - 1) != AIR) {
						NegativeZ.L_NP = 10;
						NegativeZ.L_PP = 10;
						PositiveY.L_NN = 10;
						PositiveY.L_PN = 10;
						if (chunk.GetBlock(x + 1, y + 1, z - 1) != AIR) {
							PositiveX.L_NP = 10;
							PositiveY.L_PN = 10;
							NegativeZ.L_PP = 10;
						}
						if (chunk.GetBlock(x - 1, y + 1, z - 1) != AIR) {
							NegativeX.L_NP = 10;
							PositiveY.L_NN = 10;
							NegativeZ.L_NP = 10;
						}
					}

					if (chunk.GetBlock(x + 1, y - 1, z) != AIR) {
						PositiveX.L_NN = 10;
						PositiveX.L_PN = 10;
						NegativeY.L_PN = 10;
						NegativeY.L_PP = 10;
						if (chunk.GetBlock(x + 1, y - 1, z + 1) != AIR) {
							PositiveX.L_NN = 10;
							NegativeY.L_PP = 10;
							PositiveZ.L_PN = 10;
						}
						if (chunk.GetBlock(x + 1, y - 1, z - 1) != AIR) {
							PositiveX.L_NN = 10;
							NegativeY.L_PN = 10;
							NegativeZ.L_PN = 10;
						}
					}
					if (chunk.GetBlock(x - 1, y - 1, z) != AIR) {
						NegativeX.L_NN = 10;
						NegativeX.L_PN = 10;
						NegativeY.L_NN = 10;
						NegativeY.L_NP = 10;
						if (chunk.GetBlock(x - 1, y - 1, z + 1) != AIR) {
							NegativeX.L_NN = 10;
							NegativeY.L_NP = 10;
							PositiveZ.L_NN = 10;
						}
						if (chunk.GetBlock(x - 1, y - 1, z - 1) != AIR) {
							NegativeX.L_NN = 10;
							NegativeY.L_NN = 10;
							NegativeZ.L_NN = 10;
						}
					}
					if (chunk.GetBlock(x, y - 1, z + 1) != AIR) {
						PositiveZ.L_NN = 10;
						PositiveZ.L_PN = 10;
						NegativeY.L_NP = 10;
						NegativeY.L_PP = 10;
						if (chunk.GetBlock(x + 1, y - 1, z + 1) != AIR) {
							PositiveX.L_NN = 10;
							NegativeY.L_PP = 10;
							PositiveZ.L_PN = 10;
						}
						if (chunk.GetBlock(x - 1, y - 1, z + 1) != AIR) {
							NegativeX.L_NN = 10;
							NegativeY.L_NP = 10;
							PositiveZ.L_NN = 10;
						}
					}
					if (chunk.GetBlock(x, y - 1, z - 1) != AIR) {
						NegativeZ.L_NN = 10;
						NegativeZ.L_PN = 10;
						NegativeY.L_NN = 10;
						NegativeY.L_PN = 10;
						if (chunk.GetBlock(x - 1, y - 1, z - 1) != AIR) {
							NegativeX.L_NN = 10;
							NegativeY.L_NN = 10;
							NegativeZ.L_NN = 10;
						}
						if (chunk.GetBlock(x + 1, y - 1, z - 1) != AIR) {
							PositiveX.L_NN = 10;
							NegativeY.L_PN = 10;
							NegativeZ.L_PN = 10;
						}
					}
				}

			}
		}
	}
}

//Simplifies mesh (Algorithm: Greedy Meshing): Similar to this https://gist.github.com/Vercidium/a3002bd083cce2bc854c9ff8f0118d33
void ChunkMeshData::SimplifyMesh(Chunk& chunk) {
	
	

	//iterate through the x, y, and z axis
	for (int axis = 0; axis < 3; axis++) {

		int x[3]{};
		int q[3]{};

		int a0 = (axis + 1) % 3;
		int a1 = (axis + 2) % 3;
		int a2 = axis;

		//iterate the back and front facing sides
		for (int facing = 0; facing < 2; facing++) {
			//iterate through each slice of a chunk 

			Quad LastQuad = NullQuad;

			for (int t = 0; t < 16; t++) {
				for (int y = 0; y < 16; y++) {
					for (int u = 0; u < 16; u++) {

						x[a0] = y;
						x[a1] = u;
						x[a2] = t;

						if (!compareQuads(GetFace(x[0], x[1], x[2], axis * 2 + facing), NullQuad)) { // Check if quad actually exist first
							LastQuad = GetFace(x[0], x[1], x[2], axis * 2 + facing); //Load in quad face

							int w = 0;
							int h = 0;
							int k = 0;

							for (w = 0; w + y < 16; w++) { // How far the width of the quad can go before hitting a quad that is different

								q[a0] = y + w;
								q[a1] = u;
								q[a2] = t;

								if (!compareQuads(GetFace(q[0], q[1], q[2], axis * 2 + facing), LastQuad))
									break;
							}

							bool done = false;
							for (h = 0; h + u < 16; h++) { // Checks how far the quad can go without hitting a different quad (different direction)
								for (k = 0; k < w; k++) {
									q[a0] = y + k;
									q[a1] = u + h;
									q[a2] = t;
									if (!compareQuads(GetFace(q[0], q[1], q[2], axis * 2 + facing), LastQuad)) {
										done = true;
										break;
									}
								}
								if (done) {
									break;
								}
							}

							//Set all of the used quads as NullQuads to prevent them from being used again;
							for (int p0 = 0; p0 < h; p0++) {
								for (int p1 = 0; p1 < k; p1++) {
									q[a0] = y + p1;
									q[a1] = u + p0;
									q[a2] = t;

									SetFace(q[0], q[1], q[2], axis * 2 + facing, NullQuad);
								}
							}

							Quad finalq = LastQuad;

							finalq.x = x[a0];
							finalq.y = x[a1];

							finalq.w = k;
							finalq.h = h;

							finalq.Texture = GetTexture(chunk,x[0], x[1], x[2], axis * 2 + facing);

							AddFacetoMesh(finalq, t, axis, facing);
							
						}
					}
				}
			}
		}
	}
}

const int xDataBitOffset = 0;
const int yDataBitOffset = 5;
const int zDataBitOffset = 10;
const int blockShadingBitOffset = 15;
const int textureBitOffset = 20;

void ChunkMeshData::AddFacetoMesh(Quad quad, int slice, int axis, int face) {

	int v[6]{};

	v[(axis)] = (slice + face) << (((axis + 0) % 3) * 5);
	v[(axis + 1) % 3] = (quad.x) << (((axis + 1) % 3) * 5);
	v[(axis + 2) % 3] = (quad.y) << (((axis + 2) % 3) * 5);

	v[(axis)+3] = (slice + face) << (((axis + 0) % 3) * 5);
	v[(axis + 1) % 3 + 3] = (quad.x + quad.w) << (((axis + 1) % 3) * 5);
	v[(axis + 2) % 3 + 3] = (quad.y + quad.h) << (((axis + 2) % 3) * 5);

	int sx = quad.w;
	int sy = quad.h;

	int a = quad.L_NN;
	int b = quad.L_NP;
	int a1 = quad.L_PN;
	int b1 = quad.L_PP;

	int tex = quad.Texture;

	//Positive X
	SolidVertices.push_back(0u | v[0] | v[1] | v[5] | (b1 << blockShadingBitOffset));
	SolidVertices.push_back(0u | (sx << 0) | (0 << 10) | (tex << textureBitOffset));
	SolidVertices.push_back(0u | v[0] | v[4] | v[2] | (a << blockShadingBitOffset));
	SolidVertices.push_back(0u | (0 << 0) | (0 << 10) | (tex << textureBitOffset));
	SolidVertices.push_back(0u | v[0] | v[1] | v[5] | (a1 << blockShadingBitOffset));
	SolidVertices.push_back(0u | (sx << 0) | (sy << 10) | (tex << textureBitOffset));
	SolidVertices.push_back(0u | v[0] | v[4] | v[2] | (a << blockShadingBitOffset));
	SolidVertices.push_back(0u | (0 << 0) | (0 << 10) | (tex << textureBitOffset));
	SolidVertices.push_back(0u | v[0] | v[1] | v[2] | (b << blockShadingBitOffset));
	SolidVertices.push_back(0u | (0 << 0) | (sy << 10) | (tex << textureBitOffset));
	SolidVertices.push_back(0u | v[0] | v[1] | v[5] | (a1 << blockShadingBitOffset));
	SolidVertices.push_back(0u | (sx << 0) | (sy << 10) | (tex << textureBitOffset));
}

//Checks if a block side is visible to the player
bool ChunkMeshData::IsFaceVisible(Chunk& chunk, int x, int y, int z, int side) {
	switch (side)
	{
	case NX:
		return chunk.GetBlock(x - 1, y, z) == AIR;
	case PX:
		return chunk.GetBlock(x + 1, y, z) == AIR;
	case NY:
		return chunk.GetBlock(x, y - 1, z) == AIR;
	case PY:
		return chunk.GetBlock(x, y + 1, z) == AIR;
	case NZ:
		return chunk.GetBlock(x, y, z - 1) == AIR;
	case PZ:
		return chunk.GetBlock(x, y, z + 1) == AIR;
	default:
		return false;
	}
}

Quad& ChunkMeshData::GetFace(int x, int y, int z, int side) {
	if (x >= 16 || y >= 16 || z >= 16 || x < 0 || y < 0 || z < 0) {
		return NullQuad;
	}
	return FaceCollectionCache[x * 1536 + y * 96 + z * 6 + side];
}

void ChunkMeshData::SetFace(int x, int y, int z, int side, Quad quad) {
	if (x >= 16 || y >= 16 || z >= 16 || x < 0 || y < 0 || z < 0) {
		return;
	}
	FaceCollectionCache[x * 1536 + y * 96 + z * 6 + side] = quad;
}

int ChunkMeshData::GetTexture(Chunk& chunk, int x, int y, int z, int side) {
	return BlockList[chunk.GetBlock(x, y, z)]->Texture->GetFace(side);
}