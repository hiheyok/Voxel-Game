#pragma once
#include "Texture.h"

RawTextureData GetImageData(const char* path);