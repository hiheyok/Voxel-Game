#pragma once
#define _CRTDBG_MAP_ALLOC
long long unsigned int getID();